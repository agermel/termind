import { definePluginEntry } from "openclaw/plugin-sdk/plugin-entry";

import { buildIncidentCard } from "./lib/card.js";
import { classifyFailure } from "./lib/classify.js";
import { computeFingerprint } from "./lib/fingerprint.js";
import { larkCliDiscoverTool } from "./lib/lark-cli-discover.js";
import { buildLarkCliCommands, larkTargetsForEvent } from "./lib/lark-cli.js";
import { larkCliStatusTool } from "./lib/lark-cli-status.js";
import { buildReportTemplate } from "./lib/report.js";
import { normalizeFailureEvent, redactFailureEvent } from "./lib/redact.js";

const failureEventSchema = {
  type: "object",
  additionalProperties: true,
  required: ["summary", "command"],
  properties: {
    fingerprint: { type: "string" },
    summary: { type: "string" },
    command: { type: "string" },
    severity: { type: "string", enum: ["info", "warning", "incident"] },
    cwd: { type: "string" },
    project: { type: "string" },
    user: { type: "string" },
    branch: { type: "string" },
    gitCommit: { type: "string" },
    environment: { type: "string" },
    tail: { type: "string" },
    larkChatId: {
      type: "string",
      description: "Legacy Feishu/Lark chat id. Prefer larkTargets."
    },
    larkUserOpenId: {
      type: "string",
      description: "Feishu/Lark user open_id for personal delivery."
    },
    larkSender: {
      type: "string",
      enum: ["bot", "user"]
    },
    larkProfile: {
      type: "string",
      description: "lark-cli profile name to use for runtime sending."
    },
    larkTargets: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: true,
        properties: {
          type: { type: "string", enum: ["chat", "user", "bot"] },
          id: { type: "string" },
          label: { type: "string" },
          enabled: { type: "boolean" }
        }
      }
    },
    stackTop: { type: "array", items: { type: "string" } },
    reportUrl: { type: "string" },
    occurrences: { type: "number" },
    affectedUsers: { type: "number" },
    branchKind: { type: "string" }
  }
};

export default definePluginEntry({
  id: "termind",
  name: "Termind",
  description: "Safe Termind terminal intelligence tools for OpenClaw orchestration.",
  register(api) {
    api.registerTool({
      name: "termind_event_redact",
      description: "Normalize and redact a Termind terminal failure event. Does not access network, shell, files, or environment.",
      parameters: failureEventSchema,
      async execute(_callId, params) {
        const event = redactFailureEvent(normalizeFailureEvent(params, { requireFingerprint: false }));
        return jsonContent({ event });
      }
    });

    api.registerTool({
      name: "termind_fingerprint_compute",
      description: "Compute a stable deterministic fingerprint for a normalized Termind failure event.",
      parameters: failureEventSchema,
      async execute(_callId, params) {
        const event = redactFailureEvent(normalizeFailureEvent(params, { requireFingerprint: false }));
        return jsonContent(computeFingerprint(event));
      }
    });

    api.registerTool({
      name: "termind_failure_classify",
      description: "Classify a Termind failure event severity and routing hints without side effects.",
      parameters: failureEventSchema,
      async execute(_callId, params) {
        const event = redactFailureEvent(normalizeFailureEvent(params, { requireFingerprint: false }));
        const fingerprint = event.fingerprint ? null : computeFingerprint(event);
        if (fingerprint) event.fingerprint = fingerprint.fingerprint;
        return jsonContent(classifyFailure(event));
      }
    });

    api.registerTool({
      name: "termind_lark_card_build",
      description: "Build Lark/Feishu interactive card JSON from a redacted Termind failure event. This tool does not send messages; use termind_lark_cli_send_command_build and OpenClaw exec to send with lark-cli.",
      parameters: failureEventSchema,
      async execute(_callId, params) {
        const event = redactFailureEvent(normalizeFailureEvent(params, { requireFingerprint: false }));
        if (!event.fingerprint) {
          event.fingerprint = computeFingerprint(event).fingerprint;
        }
        const classification = classifyFailure(event);
        event.severity = classification.severity;
        return jsonContent({
          event,
          classification,
          card: buildIncidentCard(event),
          sendHint: {
            preferred: "lark-cli",
            tool: "termind_lark_cli_send_command_build",
            execTool: "exec",
            targets: larkTargetsForEvent(event)
          }
        });
      }
    });

    api.registerTool({
      name: "termind_lark_cli_send_command_build",
      description: "Build safe lark-cli commands for sending a Termind Lark/Feishu interactive card. This tool returns command argv only and does not execute shell commands.",
      parameters: {
        type: "object",
        additionalProperties: true,
        required: ["event", "card"],
        properties: {
          event: failureEventSchema,
          card: { type: "object" }
        }
      },
      async execute(_callId, params) {
        const event = redactFailureEvent(normalizeFailureEvent(params.event ?? {}, { requireFingerprint: false }));
        const card = params.card;
        const commands = buildLarkCliCommands(event, card);
        return jsonContent({
          preferred: "lark-cli",
          commands,
          missingTarget: commands.length === 0,
          exec: {
            tool: "exec",
            requiresAllowlist: "lark-cli"
          }
        });
      }
    });

    api.registerTool({
      name: "termind_lark_cli_status",
      description: "Build and parse OpenClaw-side lark-cli status checks. This tool does not execute shell commands; use OpenClaw exec for returned commands, then call this tool with action=parse.",
      parameters: {
        type: "object",
        additionalProperties: true,
        properties: {
          action: { type: "string", enum: ["plan", "parse"] },
          profiles: {},
          profileListOutput: { type: "string" },
          profileListError: { type: "string" },
          versionError: { type: "string" },
          doctorExitCode: { type: "number" },
          doctorOutput: { type: "string" },
          selfUserOutput: { type: "string" }
        }
      },
      async execute(_callId, params) {
        return jsonContent(larkCliStatusTool(params));
      }
    });

    api.registerTool({
      name: "termind_lark_cli_discover",
      description: "Build and parse OpenClaw-side lark-cli target discovery checks for chats or users. This tool does not execute shell commands; use OpenClaw exec for returned commands, then call this tool with action=parse.",
      parameters: {
        type: "object",
        additionalProperties: true,
        properties: {
          action: { type: "string", enum: ["plan", "parse"] },
          kind: { type: "string", enum: ["chat", "user"] },
          profile: { type: "string" },
          query: { type: "string" },
          memberOpenID: { type: "string" },
          chatSearchOutput: { type: "string" },
          chatSearchError: { type: "string" },
          chatListOutput: { type: "string" },
          chatListError: { type: "string" },
          userSearchOutput: { type: "string" },
          userSearchError: { type: "string" }
        }
      },
      async execute(_callId, params) {
        return jsonContent(larkCliDiscoverTool(params));
      }
    });

    api.registerTool({
      name: "termind_report_template_build",
      description: "Build a Markdown incident report template from a redacted Termind failure event.",
      parameters: failureEventSchema,
      async execute(_callId, params) {
        const event = redactFailureEvent(normalizeFailureEvent(params, { requireFingerprint: false }));
        if (!event.fingerprint) {
          event.fingerprint = computeFingerprint(event).fingerprint;
        }
        return jsonContent({
          event,
          markdown: buildReportTemplate(event)
        });
      }
    });

    api.log?.info?.("registered safe Termind tools");
  }
});

function jsonContent(value) {
  return {
    content: [
      {
        type: "text",
        text: JSON.stringify(value, null, 2)
      }
    ]
  };
}
